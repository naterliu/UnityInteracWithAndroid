using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SDKTest : MonoBehaviour
{
    private AndroidJavaClass jc;
    private AndroidJavaObject jo;

    private Button btn;
    private Text text;

    // Start is called before the first frame update
    void Start()
    {
        btn = GameObject.Find("Button").GetComponent<Button>();
        text = GameObject.Find("Text").GetComponent<Text>();

        // �������ǹ̶�д��
        jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");    // ��ȡ��UnityPlayer��
        jo = jc.GetStatic<AndroidJavaObject>("currentActivity");    // ��ȡ���ʵ��

        btn.onClick.AddListener(OnBtnClickHandler);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnBtnClickHandler()
    {
        Debug.Log("����Android�еķ��� UnityCallMethod");
        // ����Android�еķ��� UnityCallMethod
        jo.Call("UnityCallMethod");
    }

    public void UnityMethod(string str)
    {
        Debug.Log("UnityMethod�����ã�������" + str);
        text.text = str;
    }
}
